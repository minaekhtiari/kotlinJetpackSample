package com.mina.kotlinSampleCode.business.domain.models

data class AuthToken(
    val accountPk: Int,
    val token: String
)













