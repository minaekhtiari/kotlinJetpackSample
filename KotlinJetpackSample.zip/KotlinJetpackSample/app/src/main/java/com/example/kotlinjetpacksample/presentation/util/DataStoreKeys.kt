package com.mina.kotlinSampleCode.presentation.util

class DataStoreKeys {

    companion object{

        // DataStore Keys


    }
}