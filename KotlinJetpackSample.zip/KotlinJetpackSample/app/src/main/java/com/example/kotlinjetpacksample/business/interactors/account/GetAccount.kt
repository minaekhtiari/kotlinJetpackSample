package com.mina.kotlinSampleCode.business.interactors.account

import com.mina.kotlinSampleCode.api.handleUseCaseException
import com.mina.kotlinSampleCode.business.datasource.network.main.ApiMainService
import com.mina.kotlinSampleCode.business.datasource.network.main.toAccount
import com.mina.kotlinSampleCode.business.domain.models.Account
import com.mina.kotlinSampleCode.business.domain.models.AuthToken
import com.mina.kotlinSampleCode.business.datasource.cache.account.AccountDao
import com.mina.kotlinSampleCode.business.datasource.cache.account.toAccount
import com.mina.kotlinSampleCode.business.datasource.cache.account.toEntity
import com.mina.kotlinSampleCode.business.domain.util.DataState
import com.mina.kotlinSampleCode.business.domain.util.ErrorHandling.Companion.ERROR_AUTH_TOKEN_INVALID
import com.mina.kotlinSampleCode.business.domain.util.ErrorHandling.Companion.ERROR_UNABLE_TO_RETRIEVE_ACCOUNT_DETAILS
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import java.lang.Exception

class GetAccount(
    private val service: ApiMainService,
    private val cache: AccountDao,
) {
    private val TAG: String = "AppDebug"

    fun execute(
        authToken: AuthToken?,
    ): Flow<DataState<Account>> = flow {
        emit(DataState.loading<Account>())
        if(authToken == null){
            throw Exception(ERROR_AUTH_TOKEN_INVALID)
        }
        // get from network
        val account = service.getAccount("Token ${authToken.token}").toAccount()

        // update/insert into the cache
        cache.insertAndReplace(account.toEntity())

        // emit from cache
        val cachedAccount = cache.searchByPk(account.pk)?.toAccount()

        if(cachedAccount == null){
            throw Exception(ERROR_UNABLE_TO_RETRIEVE_ACCOUNT_DETAILS)
        }

        emit(DataState.data(response = null, cachedAccount))
    }.catch { e ->
        emit(handleUseCaseException(e))
    }
}















