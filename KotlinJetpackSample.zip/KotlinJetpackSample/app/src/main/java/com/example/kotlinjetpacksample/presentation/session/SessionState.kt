package com.mina.kotlinSampleCode.presentation.session

import com.mina.kotlinSampleCode.business.domain.models.AuthToken
import com.mina.kotlinSampleCode.business.domain.util.Queue
import com.mina.kotlinSampleCode.business.domain.util.StateMessage

data class SessionState(
    val isLoading: Boolean = false,
    val authToken: AuthToken? = null,
    val didCheckForPreviousAuthUser: Boolean = false,
    val queue: Queue<StateMessage> = Queue(mutableListOf()),
)
