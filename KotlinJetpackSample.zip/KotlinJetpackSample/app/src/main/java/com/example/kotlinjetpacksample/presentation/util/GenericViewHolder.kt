package com.mina.kotlinSampleCode.presentation.util

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class GenericViewHolder
constructor(
    itemView: View
): RecyclerView.ViewHolder(itemView){


}