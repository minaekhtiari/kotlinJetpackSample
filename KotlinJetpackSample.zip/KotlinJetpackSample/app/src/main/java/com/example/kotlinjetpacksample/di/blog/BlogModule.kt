package com.mina.kotlinSampleCode.di.blog

import com.mina.kotlinSampleCode.business.datasource.cache.blog.BlogPostDao
import com.mina.kotlinSampleCode.business.datasource.datastore.AppDataStore
import com.mina.kotlinSampleCode.business.datasource.network.main.ApiMainService
import com.mina.kotlinSampleCode.business.interactors.blog.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object BlogModule {

    @Singleton
    @Provides
    fun provideGetBlogFromCache(
        dao: BlogPostDao
    ): GetBlogFromCache{
        return GetBlogFromCache(dao)
    }

    @Singleton
    @Provides
    fun provideIsAuthorOfBlogPost(
        service: ApiMainService
    ): IsAuthorOfBlogPost{
        return IsAuthorOfBlogPost(service)
    }

    @Singleton
    @Provides
    fun provideSearchBlogs(
        service: ApiMainService,
        dao: BlogPostDao,
    ): SearchBlogs{
        return SearchBlogs(service, dao)
    }

    @Singleton
    @Provides
    fun provideDeleteBlog(
        service: ApiMainService,
        dao: BlogPostDao,
    ): DeleteBlogPost{
        return DeleteBlogPost(service, dao)
    }

    @Singleton
    @Provides
    fun provideUpdateBlog(
        service: ApiMainService,
        dao: BlogPostDao,
    ): UpdateBlogPost{
        return UpdateBlogPost(service, dao)
    }

    @Singleton
    @Provides
    fun providePublishBlog(
        service: ApiMainService,
        dao: BlogPostDao,
    ): PublishBlog{
        return PublishBlog(service, dao)
    }

    @Singleton
    @Provides
    fun provideGetOrderAndFilter(
        appDataStoreManager: AppDataStore
    ): GetOrderAndFilter{
        return GetOrderAndFilter(appDataStoreManager)
    }

    @Singleton
    @Provides
    fun provideConfirmBlogExistsOnServer(
        service: ApiMainService,
        cache: BlogPostDao,
    ): ConfirmBlogExistsOnServer{
        return ConfirmBlogExistsOnServer(service = service, cache = cache)
    }
}

















