package com.mina.kotlinSampleCode.presentation.auth.login

import com.mina.kotlinSampleCode.business.domain.util.Queue
import com.mina.kotlinSampleCode.business.domain.util.StateMessage

data class LoginState(
    val isLoading: Boolean = false,
    val email: String = "",
    val password: String = "",
    val queue: Queue<StateMessage> = Queue(mutableListOf()),
)
