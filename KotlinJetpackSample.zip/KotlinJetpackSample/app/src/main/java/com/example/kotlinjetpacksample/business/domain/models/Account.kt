package com.mina.kotlinSampleCode.business.domain.models

data class Account(
    val pk: Int,
    val email: String,
    val username: String
)









