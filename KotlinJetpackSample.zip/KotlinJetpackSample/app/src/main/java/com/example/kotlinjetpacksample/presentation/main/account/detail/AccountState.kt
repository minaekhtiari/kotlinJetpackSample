package com.mina.kotlinSampleCode.presentation.main.account.detail

import com.mina.kotlinSampleCode.business.domain.models.Account
import com.mina.kotlinSampleCode.business.domain.util.Queue
import com.mina.kotlinSampleCode.business.domain.util.StateMessage

data class AccountState(
    val isLoading: Boolean = false,
    val account: Account? = null,
    val queue: Queue<StateMessage> = Queue(mutableListOf()),
)
