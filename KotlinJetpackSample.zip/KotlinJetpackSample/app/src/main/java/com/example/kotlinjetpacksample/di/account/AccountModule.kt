package com.mina.kotlinSampleCode.di.account

import com.mina.kotlinSampleCode.business.datasource.network.main.ApiMainService
import com.mina.kotlinSampleCode.business.interactors.account.GetAccount
import com.mina.kotlinSampleCode.business.interactors.account.GetAccountFromCache
import com.mina.kotlinSampleCode.business.interactors.account.UpdateAccount
import com.mina.kotlinSampleCode.business.interactors.account.UpdatePassword
import com.mina.kotlinSampleCode.business.datasource.cache.account.AccountDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AccountModule {

    @Singleton
    @Provides
    fun provideGetAccount(
        service: ApiMainService,
        cache: AccountDao,
    ): GetAccount{
        return GetAccount(service, cache)
    }

    @Singleton
    @Provides
    fun provideUpdateAccount(
        service: ApiMainService,
        cache: AccountDao,
    ): UpdateAccount{
        return UpdateAccount(service, cache)
    }

    @Singleton
    @Provides
    fun provideGetAccountFromCache(
        cache: AccountDao,
    ): GetAccountFromCache{
        return GetAccountFromCache(cache)
    }

    @Singleton
    @Provides
    fun provideUpdatePassword(
        service: ApiMainService,
        cache: AccountDao,
    ): UpdatePassword{
        return UpdatePassword(service)
    }
}










