package com.mina.kotlinSampleCode.presentation.main.create_blog

import android.net.Uri
import com.mina.kotlinSampleCode.business.domain.util.Queue
import com.mina.kotlinSampleCode.business.domain.util.StateMessage

data class CreateBlogState(
    val isLoading: Boolean = false,
    val title: String = "",
    val body: String = "",
    val uri: Uri? = null,
    val onPublishSuccess: Boolean = false,
    val queue: Queue<StateMessage> = Queue(mutableListOf()),
)

