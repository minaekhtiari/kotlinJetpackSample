package com.mina.kotlinSampleCode.presentation.auth.forgot_password

import com.mina.kotlinSampleCode.business.domain.util.Queue
import com.mina.kotlinSampleCode.business.domain.util.StateMessage

data class ForgotPasswordState(
    val isLoading: Boolean = false,
    val isPasswordResetLinkSent: Boolean = false,
    val queue: Queue<StateMessage> = Queue(mutableListOf()),
)
