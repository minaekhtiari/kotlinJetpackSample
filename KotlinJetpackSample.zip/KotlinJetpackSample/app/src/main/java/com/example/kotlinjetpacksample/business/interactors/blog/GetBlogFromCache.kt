package com.mina.kotlinSampleCode.business.interactors.blog

import com.mina.kotlinSampleCode.api.handleUseCaseException
import com.mina.kotlinSampleCode.business.domain.models.BlogPost
import com.mina.kotlinSampleCode.business.datasource.cache.blog.BlogPostDao
import com.mina.kotlinSampleCode.business.datasource.cache.blog.toBlogPost
import com.mina.kotlinSampleCode.business.domain.util.DataState
import com.mina.kotlinSampleCode.business.domain.util.ErrorHandling.Companion.ERROR_BLOG_UNABLE_TO_RETRIEVE
import com.mina.kotlinSampleCode.business.domain.util.MessageType
import com.mina.kotlinSampleCode.business.domain.util.Response
import com.mina.kotlinSampleCode.business.domain.util.UIComponentType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

class GetBlogFromCache(
    private val cache: BlogPostDao,
) {

    fun execute(
        pk: Int,
    ): Flow<DataState<BlogPost>> = flow{
        emit(DataState.loading<BlogPost>())
        val blogPost = cache.getBlogPost(pk)?.toBlogPost()

        if(blogPost != null){
            emit(DataState.data(response = null, data = blogPost))
        }
        else{
            emit(DataState.error<BlogPost>(
                response = Response(
                    message = ERROR_BLOG_UNABLE_TO_RETRIEVE,
                    uiComponentType = UIComponentType.Dialog(),
                    messageType = MessageType.Error()
                )
            ))
        }
    }.catch { e ->
        emit(handleUseCaseException(e))
    }
}



















